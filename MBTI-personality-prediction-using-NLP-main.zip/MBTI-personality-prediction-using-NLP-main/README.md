## MBTI-personality-prediction-using-NLP
To predict your personality type do the following steps.
1. Download the dataset from https://www.kaggle.com/datasets/zeyadkhalid/mbti-personality-types-500-dataset
2. Upload the dataset in your google drive in colab notebooks folder.
3. Go to https://github.com/Sambhavmahajan11/MBTI-personality-prediction-using-NLP
4. Open the NLP-code.ipynb file and click on the open with colab option.
5. Run the code by clicking on Runtime->Run all
6. Go to https://mbti-personality.anvil.app/
7. Fill the text box with the text and click on submit button.
8. The personality type will be displayed on the website.
